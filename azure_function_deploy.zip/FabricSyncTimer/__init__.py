"""
Azure Function para sincronizar DRE do Fabric para Supabase
Executa diariamente as 08:00
"""

import logging
import struct
import pyodbc
import requests
import json
import os
from datetime import datetime, date, time
from decimal import Decimal
from azure.identity import ClientSecretCredential

# Configuracoes (vem das variaveis de ambiente)
FABRIC_SERVER = os.environ['FABRIC_SERVER']
FABRIC_DATABASE = os.environ['FABRIC_DATABASE']
TENANT_ID = os.environ['TENANT_ID']
CLIENT_ID = os.environ['CLIENT_ID']
CLIENT_SECRET = os.environ['CLIENT_SECRET']
SUPABASE_URL = os.environ['SUPABASE_URL']
SUPABASE_KEY = os.environ['SUPABASE_KEY']
SUPABASE_TABLE = 'dre_fabric'
DATA_MINIMA = '2026-01-01'

def main(mytimer) -> None:
    logging.info('Iniciando sincronizacao DRE Fabric -> Supabase')

    try:
        # Conectar ao Fabric
        conn = conectar_fabric()
        logging.info('Conectado ao Fabric')

        # Buscar dados
        records = buscar_dados_tratados(conn)
        logging.info(f'Encontrados {len(records)} registros')

        conn.close()

        if records:
            # Limpar tabela Supabase
            limpar_tabela_supabase()
            logging.info('Tabela limpa')

            # Inserir dados
            inserir_supabase(records)
            logging.info(f'Inseridos {len(records)} registros')

        logging.info('Sincronizacao concluida com sucesso!')

    except Exception as e:
        logging.error(f'Erro na sincronizacao: {e}')
        raise

def get_azure_token():
    """Obtem token usando Service Principal"""
    credential = ClientSecretCredential(
        tenant_id=TENANT_ID,
        client_id=CLIENT_ID,
        client_secret=CLIENT_SECRET
    )
    token = credential.get_token("https://database.windows.net/.default")
    return token.token

def converter_data_brasileira(value):
    """Converte data brasileira DD/MM/YYYY para YYYY-MM-DD"""
    if isinstance(value, str) and '/' in value:
        try:
            parts = value.split('/')
            if len(parts) == 3:
                dia, mes, ano = parts
                return f"{ano}-{mes.zfill(2)}-{dia.zfill(2)}"
        except:
            pass
    return value

def limpar_valor_numerico(value):
    """Converte valores numericos com virgula para float ou int"""
    if isinstance(value, str):
        value = value.strip()
        value = value.replace(',', '.')
        try:
            float_val = float(value)
            if float_val.is_integer():
                return int(float_val)
            return float_val
        except:
            return value
    elif isinstance(value, float):
        if value.is_integer():
            return int(value)
        return value
    return value

def conectar_fabric():
    """Conecta ao Fabric com Service Principal"""
    token = get_azure_token()
    token_bytes = token.encode('utf-16-le')
    token_struct = struct.pack(f'<I{len(token_bytes)}s', len(token_bytes), token_bytes)

    connection_string = (
        f"Driver={{ODBC Driver 18 for SQL Server}};"
        f"Server={FABRIC_SERVER};"
        f"Database={FABRIC_DATABASE};"
        f"Encrypt=yes;"
        f"TrustServerCertificate=no;"
        f"Connection Timeout=30;"
    )

    conn = pyodbc.connect(connection_string, attrs_before={1256: token_struct})
    return conn

def buscar_dados_tratados(conn):
    """Busca dados tratados do DRE"""
    query = f"""
    SELECT
        CONCAT(F.IDLANCAMENTO, F.IDPARTIDA) AS CHAVE,
        CODLOTE, FIL.CIA, FIL.FILIAL, F.INTEGRAAPLICACAO, F.IDPARTIDA,
        F.FLUIG AS TICKET,
        CASE
            WHEN F.CODIGOFORNECEDOR = '' AND (COMPLEMENTO LIKE '%N/ MES%' OR COMPLEMENTO LIKE '%N/ MÊS%' OR COMPLEMENTO LIKE '%N/MÊS%') THEN COMPLEMENTO
            WHEN F.CODIGOFORNECEDOR = '' AND (COMPLEMENTO LIKE 'EV____ -%' OR COMPLEMENTO LIKE 'EN____ -%') THEN COMPLEMENTO
            WHEN F.CODIGOFORNECEDOR = '' THEN F.FORNECEDOR_TRATADO
            WHEN FORN_TAG.[Fornecedor Novo] IS NOT NULL THEN FORN_TAG.[Fornecedor Novo]
            ELSE F.NOMEFORNECEDOR
        END AS FORNECEDOR_PADRAO,
        FORMAT(F.DATA,'yyyyMM') AS ANOMES,
        F.VALOR, F.COMPLEMENTO, 'Sim' AS RECORRENTE,
        CASE WHEN T.Tag1 NOT IN ('CUSTOS', 'DESPESAS') THEN F.CONTA ELSE F.CONTA END AS CONTA,
        CASE WHEN T.Tag1 NOT IN ('CUSTOS', 'DESPESAS') THEN T.Tag1 ELSE T.Tag1 END AS TAG1,
        CASE WHEN T.Tag1 NOT IN ('CUSTOS', 'DESPESAS') THEN T.Tag2 ELSE T.Tag2 END AS TAG2,
        CASE WHEN T.Tag1 NOT IN ('CUSTOS', 'DESPESAS') THEN T.Tag3 ELSE T.Tag3 END AS TAG3,
        CASE WHEN T.Tag1 NOT IN ('CUSTOS', 'DESPESAS') THEN T.TAG4 ELSE T.TAG4 END AS TAG4,
        CASE WHEN T.TagOrc NOT IN ('CUSTOS', 'DESPESAS') THEN T.TagOrc ELSE T.TagOrc END AS TAG_ORC,
        'Original' AS ORIGINAL, 'Real' AS R_O, F.CC, F.CODCOLIGADA, F.CODFILIAL, F.USUARIO,
        F.CONTA AS CONTA_ORIGINAL, T.Tag1 AS TAG1_ORIGINAL, T.TAG4 AS TAG4_ORIGINAL,
        T.TagOrc AS TAGORC_ORIGINAL, F.INTEGRACHAVE_TRATADA,
        [STATUS LANC. FINANCEIRO] AS STATUS_LANC_FINANCEIRO,
        FORMAT(F.DATA,'yyyyMM') AS ANOMES_ORIGINAL
    FROM DRE F
    LEFT JOIN Filial FIL ON FIL.CODCOLIGADA = F.CODCOLIGADA AND FIL.CODFILIAL = F.CODFILIAL
    LEFT JOIN Tags T ON T.CODCONTA = F.CONTA
    LEFT JOIN Fornecedor_Tags FORN_TAG ON TRIM(FORN_TAG.[Fornecedor Original]) = TRIM(F.NOMEFORNECEDOR)
    WHERE F.DATA >= '{DATA_MINIMA}' AND F.DATA <= GETDATE()
    AND T.Tag1 != 'N/A'
    ORDER BY F.CODCOLIGADA, F.IDLANCAMENTO, F.IDPARTIDA
    """

    cursor = conn.cursor()
    cursor.execute(query)
    columns = [column[0] for column in cursor.description]
    rows = cursor.fetchall()

    records = []
    for row in rows:
        record = {}
        for i, value in enumerate(row):
            col_name = columns[i].lower()
            if isinstance(value, (datetime, date)):
                record[col_name] = value.strftime('%Y-%m-%d')
            elif isinstance(value, time):
                record[col_name] = value.strftime('%H:%M:%S')
            elif isinstance(value, Decimal):
                record[col_name] = float(value)
            elif value is None:
                record[col_name] = None
            else:
                value = converter_data_brasileira(value)
                record[col_name] = limpar_valor_numerico(value)
        records.append(record)

    return records

def limpar_tabela_supabase():
    """Limpa tabela no Supabase"""
    url = f"{SUPABASE_URL}/rest/v1/{SUPABASE_TABLE}?id=gt.0"
    headers = {
        'apikey': SUPABASE_KEY,
        'Authorization': f'Bearer {SUPABASE_KEY}',
        'Content-Type': 'application/json',
        'Prefer': 'return=minimal'
    }
    requests.delete(url, headers=headers)

def inserir_supabase(records):
    """Insere dados no Supabase usando SQL Function (bypassa cache)"""
    url = f"{SUPABASE_URL}/rest/v1/rpc/insert_dre_batch"
    headers = {
        'apikey': SUPABASE_KEY,
        'Authorization': f'Bearer {SUPABASE_KEY}',
        'Content-Type': 'application/json'
    }

    batch_size = 1000
    total_inseridos = 0

    for i in range(0, len(records), batch_size):
        batch = records[i:i + batch_size]
        payload = {"dados": batch}
        response = requests.post(url, headers=headers, json=payload)

        if response.status_code in [200, 201, 204]:
            total_inseridos += len(batch)
            logging.info(f'Batch {(i//batch_size)+1}: {len(batch)} registros inseridos')
        else:
            raise Exception(f'Erro ao inserir batch {(i//batch_size)+1}: Status {response.status_code} - {response.text[:200]}')
